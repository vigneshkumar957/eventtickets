self.addEventListener("install", function (event) {
  console.log("Hello world from the Service Worker 🤙");
});
