This is a project that I'm currently working on to replicate some of the functionality from Ticketmaster. 


# Tech stack
- Nextjs
- React
- MySQL
- TailwindCSS

cd eventtickets
npm install

# Enter DATABASE_URL in .env

npm run dev

http://localhost:3000
```
